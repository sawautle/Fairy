"""Sandbox package for Fairy."""
