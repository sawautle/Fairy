"""Skills package for Fairy."""
