"""Controller package for Fairy."""
