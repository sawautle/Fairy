"""Core package for Fairy."""
